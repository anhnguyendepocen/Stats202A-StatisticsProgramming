#' QR Decomposition Function
#' 
#' This function performs QR decomposition on matrix A
#' 
#' @param  A an n x m numeric matrix
#' @return list containing Q.transpose and R - Q is an orthogonal n x n matrix and R is an upper triangular n x m matrix. Q and R satisfy the equation: A = Q %*% R 
#' @keywords QR decomposition
#' @export



QR <- function(A){
  
  ## Perform QR decomposition on the matrix A
  ## Input: 
  ## A, an n x m matrix
  
  ########################
  ## FILL IN CODE BELOW ##
  ########################  
  n <- dim(A)[1]
  m <- dim(A)[2]
  R <- A
  Q <- diag(n)
  
  for(k in 1: (m - 1)){
    x <- matrix(0, n,1)
    x[k:n, 1] <- R[k:n, k]
    v <- x
    v[k] <- x[k] + sign(x[k,1]) * norm(x, type = "F")
    s <- norm(v, type = "F")
    
    if( s != 0){
      u <- v / s
      R <- R - 2 * (u %*% (t(u) %*% R))
      Q <- Q - 2 * (u %*% (t(u) %*% Q))
    }
  }
  
  
  ## Function should output a list with Q.transpose and R
  ## Q is an orthogonal n x n matrix
  ## R is an upper triangular n x m matrix
  ## Q and R satisfy the equation: A = Q %*% R
  return(list("Q" = t(Q), "R" = R))
  
}