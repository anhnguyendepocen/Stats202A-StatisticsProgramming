#' A PCA Function
#' 
#' This function performs PCA on matrix A using the QR function
#' 
#' @param A a square matrix
#' @param numIter number of iterations - default is 1000
#' @return list of D and V; D is a vector of eigen values of A, V is a matrix of eigen vectors of A (same order as eigen values)
#' @keywords
#' PCA
#' Eigen Values
#' Eigen Vectors
#' @export


PCA <- function(A, numIter = 1000){
  ## Perform PCA on matrix A using your QR function, myQRC.
  ## Input:
  ## A: Square matrix
  ## numIter: Number of iterations
  
  ########################
  ## FILL IN CODE BELOW ##
  ########################  
  
  rows <- nrow(A)
  cols <- ncol(A)
  V <- matrix(runif(rows * rows), rows, rows)
  
  for(i in 1:numIter){
    Q <- QR(V)$Q
    V <- A %*% Q
  }
  
  eigen_out <- QR(V)
  Q <- eigen_out$Q
  R <- eigen_out$R
  
  ## Function should output a list with D and V
  ## D is a vector of eigenvalues of A
  ## V is the matrix of eigenvectors of A (in the 
  ## same order as the eigenvalues in D.)
  return(list("D" = diag(R), "V" = Q))
}