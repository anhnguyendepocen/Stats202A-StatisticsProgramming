#' An expit/sigmoid function
#' @export

expit <- function(x){
  1 / (1 + exp(-x))
}