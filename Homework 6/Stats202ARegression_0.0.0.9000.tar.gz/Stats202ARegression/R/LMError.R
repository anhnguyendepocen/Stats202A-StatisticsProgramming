#' Linear Regression Standard Error
#'
#' This function calculates error of linear regression
#' @param X an n x p matrix of explanatory variables
#' @param Y n dimensional vector of responses
#' @param my_coef response of linear regression
#' @keywords linear regression RSS error
#' @export

LMError <- function(X, Y, my_coef){
  #find the standard error of linear regression
  
  n <- nrow(X)
  p <- ncol(X)
  xBias <- cbind(rep(1, n), X)
  xtxInterval <- solve(t(xBias) %*% xBias)

  RSS <- sum(((xBias %*% matrix(my_coef)) - Y) ^ 2)
  sigmaSquared <- RSS/(n - p - 1)
  standardError <- sqrt(diag(sigmaSquared * xtxInterval))

  return(standardError)
}
